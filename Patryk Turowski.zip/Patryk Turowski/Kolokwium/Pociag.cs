﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokwium
{
    class Pociag : IPodroz
    {
        private Stack<Stacja> trasaPociagu = new Stack<Stacja>();
        protected double koszt;

        public Pociag()
        {
            koszt = 100;
        }
        virtual public double KosztPoRabacie()
        {
            koszt = koszt - (koszt * 0.1);
        }

        public void DodajStacje(string nazwaStacji, bool oplataKlimatyczna)
        {
            trasaPociagu.Add(new Stacja(nazwaStacji, oplataKlimatyczna));
            if (oplataKlimatyczna = true)
            {
                koszt = koszt + 15;
            }

        }
        public string ToString()
        {
            string opis = "";
            opis += "Trasa pociagu: " + Environment.NewLine;
            opis += "Stacja: " + Stacja + Environment.NewLine;
            opis += "Koszt po rabacie:" + koszt;
            return opis;
        }
        public void Powrot();
        public void UsunStacje();
        public void ZapiszPodroz();
    }
}
*/