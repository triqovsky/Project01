﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokwium
{
    class Stacja : ICloneable
    {
        private string nazwaStacji;
        private bool oplataKlimatyczna;
        private Stacja(string nazwaStacji, bool oplataKlimatyczna)
        {
            this.nazwaStacji = nazwaStacji;
            this.oplataKlimatyczna = oplataKlimatyczna;
        }
        static public Stacja UtworzStacje(string nazwaStacji, bool oplataKlimatyczna)
        {
            return new Stacja(nazwaStacji, oplataKlimatyczna);
        }
        public override string ToString()
        {
            return "Stacja: " + nazwaStacji + "Oplata klimatyczna:" + oplataKlimatyczna;
        }
        public object Clone()
        {
            return this.MemberwiseClone();
        }

    }
}
